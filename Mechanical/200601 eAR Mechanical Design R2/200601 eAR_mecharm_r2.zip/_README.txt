The content of eAR_armmech_r2.zip is the solid works files of eAR Mechanic using GEARS. It has two configuration to smash the AMBU, half moon and spade in U.
1) unzip the eAR_armmech_r2.zip
2) unzip the eAR_Board.zip (the folder: "\Board") inside the folder of eAR_armmech_r2, it should be: \eAR_armmech_r2\Board

The file eAR_armmech_r2_meialua_step.zip is the configuration of half moon in step file.

The file eAR_armmech_r2_pa_em_U_step.zip is the configuration of spade in U in step file.