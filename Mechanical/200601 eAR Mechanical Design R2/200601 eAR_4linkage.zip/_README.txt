The content of eAR_4linkage.zip is the solid works files of eAR Mechanic using GEARS. It has two configuration to smash the AMBU, spade in L and spade in U.
1) unzip the eAR_4linkage.zip
2) unzip the eAR_Board.zip (the folder: "\Board") inside the folder of eAR_4linkage, it should be: \eAR_4linkage\Board

The file eAR_4linkage_rev2_pa_L_step.zip is the configuration of spdae in L in step file.

The file eAR_4linkage_rev2_pa_U_step.zip is the configuration of spade in U in step file.